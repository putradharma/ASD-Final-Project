#include <iostream>
using namespace std;

#include "list_child.h"

void connect(address_parent P, address_child &C);
void disconnect(address_child &C);

int main() {
    cout << "Bentuk I - Contoh Relasi 1-N" << endl;

    List_parent LP;
    List_child LC;
    address_child C;
    address_parent P;

    createList(LP);
    createList(LC);

    /** insert parent */
    P = alokasi("Square Enix",1,"A");
    insertFirst(LP, P);
    P = alokasi("Bandai Namco",2,"A");
    insertFirst(LP, P);
    P = alokasi("Koei Tecmo",3,"A");
    insertFirst(LP, P);
    P = alokasi("Codemasters",4,"B");
    insertFirst(LP, P);

    cout<<"list parent"<<endl;
    printInfo(LP);

    /** insert child */
    C = alokasi("A",11);
    insertFirst(LC, C);
    C = alokasi("D",14);
    insertFirst(LC, C);
    C = alokasi("E",15);
    insertFirst(LC, C);
    C = alokasi("O",25);
    insertFirst(LC, C);

    cout<<"list child"<<endl;
    printInfo(LC);

    /** RELASIKAN CHILD DENGAN PARENT */
    P = findElm(LP,"Square Enix");
    C = findElm(LC, "D");
    connect(P,C);
    C = findElm(LC, "O");
    connect(P,C);

    P = findElm(LP,"Bandai Namco");
    C = findElm(LC, "E");
    connect(P,C);

    P = findElm(LP,"Codemasters");
    C = findElm(LC, "A");
    connect(P,C);

    cout<<"list child setelah direlasikan"<<endl;
    printInfo(LC);

    P = findElm(LP,"Square Enix");
    C = findElm(LC, "O");
    disconnect(C);

    cout<< "list child setelah diupdate"<<endl;
    printInfo(LC);


    return 0;
}

void connect(address_parent P, address_child &C) {
    parent(C) = P;
    pub(C) = info(P);
}

void disconnect(address_child &C) {
    parent(C) = NULL;
    pub(C) = "(none)";
}

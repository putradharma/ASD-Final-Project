#include "list_child.h"

void createList(List_child &L) {
    /* Name: Putra Dharma Bangsa
        SID: 1301180523 */
    first(L) = NULL;
    last(L) = NULL;
}

address_child alokasi(infotype_child x, id_child id) {
    /* Name: Putra Dharma Bangsa
        SID: 1301180523 */
    address_child P = new elmlist_child;
    info(P) = x;
    name(P) = x;
    id(P) = id;
    pub(P) = "none";
    next(P) = NULL;
    prev(P) = NULL;
    parent(P) = NULL;
    return P;
}

void insertFirst(List_child &L, address_child P) {
    /* Name: Putra Dharma Bangsa
        SID: 1301180523 */
    if(first(L) == NULL) {
        last(L) = P;
        first(L) = P;
    } else {
        next(P) = first(L);
        prev(first(L)) = P;
        first(L) = P;
    }
}

void printInfo(List_child L) {
    /* Name: Putra Dharma Bangsa
        SID: 1301180523 */
    address_child P = first(L);
    while(P !=NULL) {
        cout<<info(P)<<", parent : ";
        if(parent(P)!=NULL)
            cout<<info(parent(P))<<endl;
        else
            cout<<"NULL"<<endl;
        cout<<" name      : "<<name(P)<<endl;
        cout<<" id        : "<<id(P)<<endl;
        cout<<" publisher : "<<pub(P)<<endl;
        P = next(P);
    }
}


address_child findElm(List_child L, infotype_child x) {
    /* Name: Putra Dharma Bangsa
        SID: 1301180523 */
    address_child P = first(L);
    while(P != NULL) {
        if(info(P)==x) {
            return P;
        }
        P = next(P);
    }
    return NULL;
}

void insertAfter(address_child &Prec, address_child P) {
    /* Name: Putra Dharma Bangsa
        SID: 1301180523 */
    prev(next(Prec)) = P;
    next(P) = next(Prec);
    prev(P) = Prec;
    next(Prec) = P;
}
void deleteFirst(List_child &L, address_child P) {
    /* Name: Putra Dharma Bangsa
        SID: 1301180523 */
    if(first(P) == last(L)){
        first(L) = NULL;
        last(L) = NULL;
    }else{
        P = first(L);
        first(L) = next(L);
        next(L) = NULL;
        prev(first(L)) = NULL;
        }
}
void deleteLast(List_child &L, address_child P) {
    if(last(P) == first(L)){
        last(L) = NULL;
        first(L) = NULL;
    }else{
        }
}

